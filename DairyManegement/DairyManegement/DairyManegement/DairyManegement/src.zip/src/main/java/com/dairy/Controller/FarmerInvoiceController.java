package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Services.FarmerInvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/FarmerInvoice")
public class FarmerInvoiceController {
    @Autowired
    private FarmerInvoiceService farmerInvoiceService;
    @GetMapping("/get/{dairyId}")
    public ResponseDTO getAllTransactionByDairyId(@PathVariable int dairyId) {
        ResponseDTO response=new ResponseDTO();
        try {
            response.data= farmerInvoiceService.getAllTransactionByDairyId(dairyId);
            response.message="Success";
            response.success=true;
            response.status=200l;
        } catch (Exception e) {
            response.message="unSuccessfully";
            response.success=false;
            response.status=500l;
        }
        return response;
    }
    @GetMapping("/getByFarmerId/{farmerId}")
    public ResponseDTO getByFarmerId(@PathVariable int farmerId){
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=farmerInvoiceService.getDataByFarmerId(farmerId);
            response.message="Success";
            response.success=true;
            response.status=200l;
        } catch (Exception e) {
            response.message="UnSuccess";
            response.success=false;
            response.status=500l;
        }
        return response;
    }
}
