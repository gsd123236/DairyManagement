package com.dairy.Services;

import com.dairy.Entity.FarmerInvoice;
import com.dairy.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FarmerInvoiceService {
    @Autowired
    private FarmerInvoiceRepository repository;
    public List<Map<String, Object>> getAllTransactionByDairyId(int dairyId) {
        List<FarmerInvoice> transactions = repository.getBalanceByDairyId(dairyId);
        return transactions.stream().map(transaction -> {
            Map<String, Object> map = new HashMap<>();
            map.put("farmerId",transaction.getFarmerRegistration().getId());
            map.put("farmerCode", transaction.getFarmerRegistration().getCode());
            map.put("farmerName", transaction.getFarmerRegistration().getFirstName()+" "+transaction.getFarmerRegistration().getLastName());
            map.put("milkAmount", String.valueOf(transaction.getMilkAmount()));
            return map;
        }).collect(Collectors.toList());
    }

    public Optional<FarmerInvoice> getDataByFarmerId(int FarmerId){
        return repository.findByFarmerId(FarmerId);
    }
}
