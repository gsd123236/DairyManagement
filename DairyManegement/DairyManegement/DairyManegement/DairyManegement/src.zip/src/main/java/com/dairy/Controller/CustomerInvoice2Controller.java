package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Repository.CustomerInvoice2Repository;
import com.dairy.Services.CustomerInvoice2Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/Invoice2")
public class CustomerInvoice2Controller {
    @Autowired
    private CustomerInvoice2Service service;

    @GetMapping("/get1/{dairyId}")
    public ResponseDTO getAllTransactionByDairyId1(@PathVariable int dairyId) {
        ResponseDTO response=new ResponseDTO();
        try {
            response.data= service.getAllTransactionByDairyId1(dairyId);
            response.message="Success";
            response.success=true;
            response.status=200l;
        } catch (Exception e) {
            response.message="unSuccessfully";
            response.success=false;
            response.status=500l;
        }
        return response;
    }
    @GetMapping("/getById/{customer_id}/{id}")
    public ResponseDTO add(@PathVariable("customer_id") int customer_id,@PathVariable ("id")int id){
        ResponseDTO response=new ResponseDTO();
        try {
            response.data= service.add2(customer_id,id);
            response.message="Successfully";
            response.success=true;
            response.status=200l;
        } catch (Exception e) {
            response.message="Failed";
            response.status=500l;
            response.success=false;
        }
        return response;

    }
}
