package com.dairy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DairyManegementApplicationTests {

	@Test
	void contextLoads() {
	}

}
