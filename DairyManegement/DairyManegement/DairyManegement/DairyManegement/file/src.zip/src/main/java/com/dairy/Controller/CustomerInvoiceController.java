package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Entity.CustomerInvoice;
import com.dairy.Services.CustomerInvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/api/Invoice")
public class CustomerInvoiceController {
    @Autowired
    private CustomerInvoiceService customerInvoiceService;
    @GetMapping("/getById/{customer_id}")
    public ResponseDTO add(@PathVariable("customer_id") int customer_id){
        ResponseDTO response=new ResponseDTO();
        try {
            response.data= customerInvoiceService.add(customer_id);
            response.message="Successfully";
            response.success=true;
            response.status=200l;
        } catch (Exception e) {
            response.message="Failed";
            response.status=500l;
            response.success=false;
        }
        return response;

    }
    @GetMapping("/getByDate/{customer_id}")
    public ResponseDTO addByDate(@PathVariable("customer_id")int customer_id, @RequestParam String startDate,@RequestParam String endDate,
                                 @RequestBody CustomerInvoice customerInvoice){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate start = LocalDate.parse(startDate, formatter);
        LocalDate end = LocalDate.parse(endDate, formatter);
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=customerInvoiceService.getByDate(customer_id,start,end, customerInvoice);
            response.success=true;
            response.status=200l;
            response.message="Successfull";
        } catch (Exception e) {
            response.status=500l;
            response.success=false;
            response.message="Failed";
        }
        return response;
    }

}
