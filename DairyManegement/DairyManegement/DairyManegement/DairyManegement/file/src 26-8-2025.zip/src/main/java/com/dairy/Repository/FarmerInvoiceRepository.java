package com.dairy.Repository;

import com.dairy.Entity.FarmerInvoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FarmerInvoiceRepository extends JpaRepository<FarmerInvoice,Integer> {
}
