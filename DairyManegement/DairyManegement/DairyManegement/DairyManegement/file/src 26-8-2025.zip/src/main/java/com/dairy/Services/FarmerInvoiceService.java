package com.dairy.Services;

import com.dairy.Entity.CustomerInvoice;
import com.dairy.Entity.CustomerRegistration;
import com.dairy.Entity.FarmerInvoice;
import com.dairy.Entity.FarmerRegistration;
import com.dairy.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class FarmerInvoiceService {
    @Autowired
    private FarmerInvoiceRepository repository;
    @Autowired
    private FarmerRegistrationRepository farmerRegistrationRepository;
    @Autowired
    private FarmerAccountRepository farmerAccountRepository;
    @Autowired
    private FarmerMilkCollectionRepository farmerMilkSaleRepository;
//    public CustomerInvoice add(int customer_id) {
//        FarmerInvoice farmerInvoice=new FarmerInvoice();
//        FarmerRegistration c = farmerRegistrationRepository.findById(customer_id)
//                .orElseThrow(() -> new RuntimeException("Not found the customer"));
//        Double balance = farmerAccountRepository.getByBalance(customer_id);
//        farmerInvoice.setBalance(balance != null ? balance : 0.0);
//        List<Double> ans= farmerMilkSaleRepository.add(customer_id);
//        Double sum=0.0;
//        int n=ans.size();
//        for(int i=0;i<n;i++){
//            sum+=ans.get(i);
//        }
////        farmerInvoice.setMilkAmount(sum);
////        List<Double>ans1= farmerMilkSaleRepository.getpaid(customer_id);
////        Double sum1=0.0;
////        int n1=ans1.size();
////        for(int i=0;i<n1;i++){
////            sum1+=ans1.get(i);
////        }
//        farmerInvoice.setFarmerRegistration(c);
////        farmerInvoice.setReceived(sum1);
//        farmerInvoice.setAmountdue(farmerInvoice.getMilkAmount() - farmerInvoice.getBalance() - farmerInvoice.getReceived());
//        farmerInvoice.setDate(LocalDate.now());
//        return repository.save(farmerInvoice);
//    }
}
