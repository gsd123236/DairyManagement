package com.dairy.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class FarmerInvoice {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private LocalDate date;
    private double milkAmount;
    private double received;
    private double balance;
    private double amountdue;
    @ManyToOne
    @JoinColumn(name = "farmer_id")
    @JsonBackReference
    private FarmerRegistration farmerRegistration;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getMilkAmount() {
        return milkAmount;
    }

    public void setMilkAmount(double milkAmount) {
        this.milkAmount = milkAmount;
    }

    public double getReceived() {
        return received;
    }

    public void setReceived(double received) {
        this.received = received;
    }

    public double getBalance() {
        return balance;
    }

    public FarmerInvoice() {
    }

    public FarmerInvoice(int id, LocalDate date, double milkAmount, double received, double balance, double amountdue, FarmerRegistration farmerRegistration) {
        this.id = id;
        this.date = date;
        this.milkAmount = milkAmount;
        this.received = received;
        this.balance = balance;
        this.amountdue = amountdue;
        this.farmerRegistration = farmerRegistration;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }


    public double getAmountdue() {
        return amountdue;
    }

    public void setAmountdue(double amountdue) {
        this.amountdue = amountdue;
    }

    public FarmerRegistration getFarmerRegistration() {
        return farmerRegistration;
    }

    public void setFarmerRegistration(FarmerRegistration farmerRegistration) {
        this.farmerRegistration = farmerRegistration;
    }
}